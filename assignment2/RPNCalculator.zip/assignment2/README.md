# SYNOPSIS

It is a simple Reverse Polish Notation Calculator.

## USAGE

1.npm install
2.tsc
3.npm start

## entry point

app.js

