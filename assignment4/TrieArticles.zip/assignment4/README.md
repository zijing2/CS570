# Trie Articles
It is a statistics about word frequency in the article implemented by trie tree.

# USAGE
1.npm install
2.tsc
3.npm start

#ENTRY POINT
./app.js (Users can refer ./package.json for the entry point and dependencies)

