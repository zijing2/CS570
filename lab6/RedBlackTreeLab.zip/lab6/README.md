#RedBlackTree-Dictionary
This is a simple Dictionary implemented by red-black tree

#USAGE

1.npm install
2.tsc
3.npm start

#ENTRY POINT
./app.js


