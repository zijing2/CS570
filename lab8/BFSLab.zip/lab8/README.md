#BFS Lab

##USAGE

npm install
tsc
npm start

##infile.dat

the 1st number of 1st line is the number of nodes
the 2st number of 1st line is the edges of nodes
the 2st line to nst line represent each edge from node n to node m

##ENTRY POINT
./app.js