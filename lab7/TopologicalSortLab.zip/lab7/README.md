## Topological Sort Lab



## USAGE
1. npm install
2. tsc
3. npm start

## ENTRY POING
./app.js